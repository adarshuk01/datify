import ably from '../config/ably.js'
import { verifyToken } from '../utils/jwt.js'
import User from '../models/User.js'
import Conversation from '../models/Conversation.js'
import Message from '../models/Message.js'
import { formatConversation } from '../controllers/chatController.js'

// ── Authenticate user from JWT ─────────────────────
export const authenticateSocketUser = async (
  token
) => {
  try {
    if (!token) {
      throw new Error(
        'Authentication required'
      )
    }

    const decoded =
      verifyToken(token)

    const user =
      await User.findById(
        decoded.id
      ).select('-password')

    if (!user) {
      throw new Error(
        'User not found'
      )
    }

    return user
  } catch {
    throw new Error(
      'Invalid token'
    )
  }
}

// ── Send message ───────────────────────────────────
export const sendMessage =
  async ({
    token,
    conversationId,
    text,
  }) => {
    try {
      const user =
        await authenticateSocketUser(
          token
        )

      const myId =
        user._id.toString()

      if (!text?.trim()) {
        throw new Error(
          'Message required'
        )
      }

      const conversation =
        await Conversation.findById(
          conversationId
        )

      if (!conversation) {
        throw new Error(
          'Conversation not found'
        )
      }

      if (
        !conversation.participants
          .map(String)
          .includes(myId)
      ) {
        throw new Error(
          'Access denied'
        )
      }

      const message =
        await Message.create({
          conversationId,
          sender: myId,
          text: text.trim(),
          readBy: [myId],
        })

      const otherIds =
        conversation.participants
          .map(String)
          .filter(
            (id) =>
              id !== myId
          )

      const unreadUpdates =
        {}

      for (const pid of otherIds) {
        unreadUpdates[
          `unreadCounts.${pid}`
        ] =
          (conversation
            .unreadCounts?.get(
              pid
            ) || 0) + 1
      }

      const updatedConv =
        await Conversation.findByIdAndUpdate(
          conversationId,
          {
            $set: {
              lastMessage:
                message._id,
              lastMessageAt:
                message.createdAt,
              ...unreadUpdates,
            },
          },
          { new: true }
        )
          .populate(
            'lastMessage'
          )
          .populate(
            'participants',
            'name photos lastActive'
          )

      const msgPayload = {
        _id: message._id,
        conversationId,
        sender: myId,
        text: message.text,
        createdAt:
          message.createdAt,
        readBy: [myId],
      }

      // Publish message
      await ably.channels
        .get(
          `conv:${conversationId}`
        )
        .publish(
          'new:message',
          msgPayload
        )

      // Update other users
      for (const pid of otherIds) {
        await ably.channels
          .get(`user:${pid}`)
          .publish(
            'conversation:updated',
            {
              conversation:
                formatConversation(
                  updatedConv,
                  pid
                ),
            }
          )
      }

      // Update sender
      await ably.channels
        .get(
          `user:${myId}`
        )
        .publish(
          'conversation:updated',
          {
            conversation:
              formatConversation(
                updatedConv,
                myId
              ),
          }
        )

      return {
        success: true,
        message: msgPayload,
      }
    } catch (err) {
      console.error(
        'Send message error:',
        err
      )

      return {
        success: false,
        error: err.message,
      }
    }
  }

// ── Typing start ───────────────────────────────────
export const emitTypingStart =
  async ({
    conversationId,
    userId,
  }) => {
    await ably.channels
      .get(
        `conv:${conversationId}`
      )
      .publish(
        'typing:start',
        {
          userId,
          conversationId,
        }
      )
  }

// ── Typing stop ────────────────────────────────────
export const emitTypingStop =
  async ({
    conversationId,
    userId,
  }) => {
    await ably.channels
      .get(
        `conv:${conversationId}`
      )
      .publish(
        'typing:stop',
        {
          userId,
          conversationId,
        }
      )
  }

// ── Mark read ──────────────────────────────────────
export const markRead =
  async ({
    conversationId,
    userId,
  }) => {
    try {
      await Message.updateMany(
        {
          conversationId,
          readBy: {
            $ne: userId,
          },
        },
        {
          $addToSet: {
            readBy: userId,
          },
        }
      )

      await Conversation.findByIdAndUpdate(
        conversationId,
        {
          $set: {
            [`unreadCounts.${userId}`]:
              0,
          },
        }
      )

      await ably.channels
        .get(
          `conv:${conversationId}`
        )
        .publish(
          'messages:read',
          {
            conversationId,
            readBy: userId,
          }
        )

      return {
        success: true,
      }
    } catch (err) {
      console.error(
        'Mark read error:',
        err
      )

      return {
        success: false,
      }
    }
  }

// ── New match notification ─────────────────────────
export const emitNewMatch =
  async (
    userAId,
    userBId
  ) => {
    await ably.channels
      .get(
        `user:${userAId}`
      )
      .publish(
        'new:match'
      )

    await ably.channels
      .get(
        `user:${userBId}`
      )
      .publish(
        'new:match'
      )
  }